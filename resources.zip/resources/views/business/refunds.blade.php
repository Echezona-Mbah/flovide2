@include('business.head')

<body class="bg-[#E9E9E9]  text-[#1E1E1E] min-h-screen flex flex-col md:flex-row">
    <!-- <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> -->

    <!-- Mobile menu button -->
    @include('business.header')

    <!-- Sidebar -->
    @include('business.sidebar')
    <!-- Overlay -->
<div id="overlay" class="fixed inset-0 bg-black bg-opacity-30 z-20 hidden md:hidden"></div>

  <main class="flex-1 p-2 md:p-8 overflow-auto ml-0 md:ml-0">
    <header class="hidden md:flex items-center justify-between mb-8 gap-4">
      <h1 class="text-2xl font-extrabold leading-tight flex-1 min-w-[200px]">
        Refunds
      </h1>
      @include('business.header_notifical')
    </header>

    <section class="mx-auto max-w-6xl">
      <div class="rounded-3xl bg-white shadow-[0_30px_70px_-40px_rgba(15,23,42,0.35)] border border-slate-100 overflow-hidden">

        <!-- Header -->
        <div class="px-6 md:px-10 py-8 bg-gradient-to-r from-sky-200 via-sky-100 to-blue-50 text-slate-900 border-b border-sky-200/70">
          <div class="flex items-center justify-between flex-wrap gap-4">
            <div>
              <p class="text-xs uppercase tracking-[0.3em] text-slate-600">Support</p>
              <h2 class="mt-2 text-2xl md:text-3xl font-black tracking-tight text-slate-900">Refund Requests</h2>
              <p class="mt-2 text-sm text-slate-600 max-w-2xl">
                Track, approve, and manage refund requests securely.
              </p>
            </div>
            <!-- <div class="rounded-2xl bg-white/70 border border-sky-200/60 px-4 py-3 text-sm text-slate-700">
              Environment: <span class="font-semibold">Live/Test</span>
            </div> -->
          </div>
        </div>

        <div class="p-6 md:p-10">
          <section class="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-8">

            <!-- Left -->
            <section class="space-y-6">
              <div class="flex flex-col sm:flex-row gap-4 sm:gap-6">
                <label for="search" class="sr-only">Search requests</label>
                <input id="search" type="search" placeholder="Search requests"
                  class="flex-1 border border-gray-300 rounded-lg py-2 px-4 text-gray-600 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500" />

                <button class="border rounded-lg px-4 py-2 bg-blue-600 text-white hover:bg-blue-700 transition"
                  id="openModalBtn">Create a Refund</button>

                <select aria-label="Filter requests" id="filter"
                  class="border border-gray-300 rounded-lg py-2 px-4 text-gray-700 cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option value="all">All requests</option>
                  <option value="approved">Approved</option>
                  <option value="rejected">Rejected</option>
                  <option value="pending">Pending</option>
                </select>
              </div>

              <section class="overflow-x-auto w-full">
                <table class="w-full border-collapse text-sm">
                  <thead>
                    <tr class="text-gray-600 font-semibold text-left border-b border-gray-200">
                      <th class="pb-3 pl-2 pr-6">Full Name</th>
                      <th class="pb-3 pr-6">Amount</th>
                      <th class="pb-3 pr-6">Approve/Reject</th>
                      <th class="pb-3 pr-2">Status</th>
                      <th class="sr-only">Details</th>
                    </tr>
                  </thead>
                  <tbody class="cursor-pointer">
                    @forelse($refunds as $refund)
                      <tr class="refundsDataRow"
                          data-id="{{ $refund->id }}"
                          data-type="{{ ucfirst($refund->type) }}"
                          data-amount="{{ number_format($refund->amount, 2) }}"
                          data-currency="{{ $refund->currency }}"
                          data-reference="{{ $refund->transaction_ref_number }}"
                          data-status="{{ ucfirst($refund->status) }}"
                          data-action="{{ $refund->action }}"
                          data-created="{{ $refund->created_at }}"
                          data-updated="{{ $refund->updated_at }}"
                          data-sender="{{ ucfirst($refund->name) }}"
                          data-reason="{{ $refund->reason }}"
                          data-recipient="{{ ucfirst($refund->recipient) }}">
                        <td class="font-normal pl-2 pr-6 py-3">{{ $refund->name }}</td>
                        <td class="pr-6 py-3 font-normal">{{ number_format($refund->amount, 2) . ' '. $refund->currency }}</td>

                        @if ($refund->action !== null)
                          @php
                            $colorBtn = strtolower($refund->action) == "approved"
                              ? "border-green-500 text-green-600"
                              : "border-red-500 text-red-600";
                          @endphp
                          <td class="pr-6 py-3">
                            <button type="button"
                              class="inline-flex items-center gap-1 border {{ $colorBtn }} rounded-lg py-1.5 px-3 font-medium cursor-pointer select-none">
                              {{ ucfirst($refund->action) }} <i class="fas fa-chevron-down text-xs"></i>
                            </button>
                          </td>
                        @else
                          <td class="pr-6 py-3">
                            <select data-id="{{ $refund->id }}"
                              class="border approval-status border-gray-300 rounded-lg py-1.5 px-3 text-gray-700 cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500"
                              aria-label="Select approval status">
                              <option value="">Select</option>
                              <option value="approved">Approved</option>
                              <option value="rejected">Rejected</option>
                            </select>
                          </td>
                        @endif

                        @php
                          $status = $refund->status;
                          if($status == "success"){
                            $color = "text-green-700 font-semibold cursor-pointer";
                          }else if($status == "processing"){
                            $color = "text-blue-700 font-semibold cursor-pointer";
                          }else if($status == "pending"){
                            $color = "text-gray-600";
                          }else{
                            $color = "text-red-600 font-semibold cursor-pointer";
                          }
                        @endphp
                        <td class="pr-2 py-3 {{ $color }}">
                          {{ strtolower($refund->status) === "success" ? "Successful" : ucfirst($refund->status) }}
                        </td>
                        <td data-id="1" class="pr-2 py-3 text-[#828282] flex items-center gap-1 cursor-pointer select-none">
                          View details
                          <i class="fas fa-external-link-alt text-xs"></i>
                        </td>
                      </tr>
                    @empty
                      <tr>
                        <td colspan="5" class="text-center py-4 text-gray-500">No refund requests found.</td>
                      </tr>
                    @endforelse
                  </tbody>
                </table>
              </section>
            </section>

            <!-- Right -->
            <section class="w-full border border-gray-200 rounded-2xl p-6 bg-gray-50">
              <div class="flex justify-between items-center h-10 mb-6 bg-gray-200 text-[12px] rounded-md p-1 font-semibold">
                <div class="bg-white cursor-pointer px-2 py-2 rounded-md navBarSection1">Transaction Details</div>
                <div class="px-2 py-2 cursor-pointer rounded-md navBarSection2">Refund Tracker</div>
              </div>
              <section class="refund-details"></section>
              <section class="trackerCont"></section>
            </section>
          </section>
        </div>
      </div>
    </section>
  </main>

  <!-- Modal (unchanged logic, styled) -->
  <div id="formModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
    <div class="bg-white w-full max-w-md rounded-2xl shadow-lg p-6 relative max-h-[90vh] overflow-y-auto border border-slate-100">
      <button id="closeModalBtn" class="absolute top-3 right-3 text-gray-500 hover:text-gray-800">✖</button>
      <h2 class="text-xl font-bold mb-4">Refund Form</h2>
      <form id="contactForm" class="space-y-4">
        <div>
          <label class="block mb-1 font-medium">Fullname</label>
          <input type="text" name="name" required class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring focus:ring-blue-300">
        </div>
        <div>
          <label class="block mb-1 font-medium">Currency</label>
          <select name="currency" id="currency" class="w-full border rounded-lg px-3 py-2 focus:ring">
            {{-- populated --}}
          </select>
        </div>
        <div>
          <label class="block mb-1 font-medium">Transaction reference</label>
          <input type="text" name="referenceNumber" required class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring focus:ring-blue-300">
        </div>
        <div>
          <label class="block mb-1 font-medium">Amount</label>
          <input type="tel" name="amount" required class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring focus:ring-blue-300">
        </div>
        <div>
          <label class="block mb-1 font-medium">Method</label>
          <select name="method" id="method" class="w-full border rounded-lg px-3 py-2 focus:ring">
            <option value="">Select Method</option>
            <option value="deposit">Deposit</option>
            <option value="online">Online</option>
          </select>
        </div>
        <div>
          <label class="block mb-1 font-medium">Reason</label>
          <textarea name="message" required class="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring focus:ring-blue-300"></textarea>
        </div>
        <button type="submit" class="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700">
          Submit
        </button>
      </form>
    </div>
  </div>


    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        const sidebar = document.getElementById('sidebar');
        const openBtn = document.getElementById('openSidebarBtn');
        const closeBtn = document.getElementById('closeSidebarBtn');
        const overlay = document.getElementById('overlay');

        function openSidebar() {
            sidebar.classList.remove('-translate-x-full');
            overlay.classList.remove('hidden');
            document.body.style.overflow = 'hidden';
        }

        function closeSidebar() {
            sidebar.classList.add('-translate-x-full');
            overlay.classList.add('hidden');
            document.body.style.overflow = '';
        }

        openBtn.addEventListener('click', openSidebar);
        closeBtn.addEventListener('click', closeSidebar);
        overlay.addEventListener('click', closeSidebar);

        // Close sidebar on window resize if desktop
        window.addEventListener('resize', () => {
            if (window.innerWidth >= 768) {
                sidebar.classList.remove('-translate-x-full');
                overlay.classList.add('hidden');
                document.body.style.overflow = '';
            } else {
                sidebar.classList.add('-translate-x-full');
            }
        });



        const trackerCont = document.querySelector(".trackerCont");
        trackerCont.style.display = "none";

        document.addEventListener('DOMContentLoaded', function () {
            const refund_details = document.querySelector('.refund-details');
            const rows = document.querySelectorAll('.refundsDataRow');

            refund_details.innerHTML = '';

            rows.forEach(row => {
                row.addEventListener('click', function () {
                    rows.forEach(r => r.classList.remove('bg-blue-50', 'font-semibold'));
                    this.classList.add('bg-blue-50', 'font-semibold');

                    const amount = this.getAttribute('data-amount');
                    const currency = this.getAttribute('data-currency');
                    const reference = this.getAttribute('data-reference');
                    const type = this.getAttribute('data-type');
                    const status = this.getAttribute('data-status');
                    const action = this.getAttribute('data-action');
                    const created_at = this.getAttribute('data-created');
                    const updated_at = this.getAttribute('data-updated');
                    const sender = this.getAttribute('data-sender');

                    const statusIcons = {
                        Success: `<i class="fas fa-check-double text-green-700"></i><span>Successful</span>`,
                        Failed: `<i class="fas fa-times-circle text-red-600"></i><span>Failed</span>`,
                        Pending: `<i class="fas fa-hourglass-half text-yellow-500"></i><span>Pending</span>`,
                        Processing: `<i class="fas fa-spinner fa-spin text-blue-500"></i><span>Processing</span>`
                    };

                    const detailHTML = `
                        <h2 class="text-2xl font-normal mb-6">${amount + ' ' + currency}</h2>

                        <div class="mb-6">
                            <p class="text-gray-600 mb-1">Transaction reference no.</p>
                            <div class="flex items-center gap-2">
                                <a href="#" lass="text-blue-800 font-semibold text-sm break-all">${reference}</a>
                                <button aria-label="Copy transaction reference number" class="text-green-600 hover:text-green-700">
                                    <i class="far fa-copy"></i>
                                </button>
                            </div>
                        </div>

                        <div class="mb-6">
                            <p class="text-gray-600 mb-1">Type</p>
                            <div class="flex items-center gap-2 text-gray-900 font-semibold">
                                <i class="fas fa-arrow-down-left text-green-600"></i>
                                <span>${type}</span>
                            </div>
                        </div>

                        <div class="mb-6">
                            <p class="text-gray-600 mb-1">Status</p>
                            <div class="flex items-center gap-2 text-gray-900 font-semibold">
                                ${statusIcons[status] || ''}
                            </div>
                        </div>

                        <div class="mb-6">
                            <p class="text-gray-600 mb-1">Time &amp; date</p>
                            <div class="flex items-center gap-2 text-gray-900 font-semibold">
                                <span>12:15:14</span>
                                <span class="border-l border-gray-400 pl-2">Aug 6, 2025</span>
                            </div>
                        </div>

                        <div class="mb-6">
                            <p class="text-gray-600 mb-1">Sender</p>
                            <p class="font-semibold text-gray-900">${sender}</p>
                        </div>

                        <div>
                            <p class="text-gray-600 mb-1">Recipient</p>
                            <a href="#" class="text-blue-800 font-semibold">Self</a>
                        </div>
                    `;

                    // Replace content
                    refund_details.innerHTML = detailHTML;

                    // Populate tracker
                    let trackerHTML = '';
                    if (status === 'Pending') {
                        trackerHTML = '<p class="text-gray-500">Choose Approve or Reject to Start Tracking..</p>';
                    } else if (status === 'Processing') {
                        trackerHTML = `
                            ${step('Refund successfully initiated', created_at, true)}
                            ${step('Processing', updated_at, true)}
                            ${step('Refund successful', '', false, false, true, true)}
                        `;
                    } else if (status === 'Success') {
                        trackerHTML = `
                            ${step('Refund successfully initiated', created_at, true)}
                            ${step('Processing', updated_at, true)}
                            ${step('Refund successful', updated_at, true, false, true)}
                        `;
                    } else if (status === 'Failed') {
                        trackerHTML = `
                            ${step('Refund successfully initiated', created_at, true)}
                            ${step('Processing', updated_at, true)}
                            ${step('Refund failed', updated_at, false, true, true)}
                        `;
                    }

                    trackerCont.innerHTML = `<div class="w-full max-w-lg mx-auto p-6">${trackerHTML}</div>`;
                });
            });

            function step(label, date, done, failed = false, isLast = false, processing = false) {
                // If the current step is "after" a processing one, force border to gray
                const borderColor = failed
                    ? 'border-red-500'
                    : processing
                        ? 'border-gray-300'
                        : done
                            ? 'border-green-500'
                            : 'border-gray-300';

                const dotColor = failed
                    ? 'bg-red-500'
                    : done
                        ? 'bg-green-500'
                        : 'bg-gray-300';
                return `
                    <div class="relative flex items-start ${failed ? 'text-red-600' : ''}">
                        <div class="absolute left-3 top-0 ${isLast ? 'h-3' : 'h-full'} border-l-2 ${borderColor}"></div>
                        <div class="relative z-10 w-6 h-6 flex items-center justify-center bg-white border-2 ${borderColor} rounded-full">
                            <div class="w-3 h-3 ${dotColor} rounded-full"></div>
                        </div>
                        <div class="ml-4 ${isLast ? '' : 'mb-8'}">
                            <h3 class="font-medium text-gray-900">${label}</h3>
                            <p class="text-sm text-gray-500">${date || ''}</p>
                        </div>
                    </div>
                `;
            }

        });

        //filter function
        document.addEventListener("DOMContentLoaded", function () {
            const filterSelect = document.getElementById("filter");
            const searchInput = document.getElementById("search");
            const rows = document.querySelectorAll(".refundsDataRow");

            function applyFilters() {
                const selectedStatus = filterSelect.value.toLowerCase();
                const searchTerm = searchInput.value.toLowerCase();

                rows.forEach(row => {
                    const rowStatus = row.dataset.action.toLowerCase();
                    const rowName = row.dataset.sender.toLowerCase();
                    const rowAmount = row.dataset.amount.toLowerCase();
                    const rowReference = row.dataset.reference.toLowerCase();

                    // Match filter
                    const statusMatch = (selectedStatus === "all" || rowStatus === selectedStatus);
                    
                    // Match search (check in name, amount, and reference)
                    const searchMatch = (
                        rowName.includes(searchTerm) ||
                        rowAmount.includes(searchTerm) ||
                        rowReference.includes(searchTerm)
                    );

                    // Show or hide based on both
                    if (statusMatch && searchMatch) {
                        row.style.display = "";
                    } else {
                        row.style.display = "none";
                    }
                });
            }

            // Listen for changes
            filterSelect.addEventListener("change", applyFilters);
            searchInput.addEventListener("input", applyFilters);
        });



        const navBarSection1 = document.querySelector(".navBarSection1");
        const navBarSection2 = document.querySelector(".navBarSection2");
        // const trackerCont = document.querySelector(".trackerCont");
        const refund_details_cont = document.querySelector(".refund-details");
        navBarSection1.addEventListener("click", ()=>{
            navBarSection2.classList.remove("bg-white");
            navBarSection1.classList.add("bg-white");
            trackerCont.style.display = "none";
            refund_details_cont.style.display = "inline-block";
        });
        navBarSection2.addEventListener("click", ()=>{
            navBarSection1.classList.remove("bg-white");
            navBarSection2.classList.add("bg-white");
            trackerCont.style.display = "inline-block";
            refund_details_cont.style.display = "none";
        });



        //toast function
        function showToast(message, type = "success") {
            Swal.fire({
                toast: true,
                position: "top-end",
                icon: type,
                title: message,
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                background: "#fff",
                color: "#333",
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                },
                didClose: () => {
                    if (type === "success") {
                        location.reload();
                    }
                }
            });
        }


        const openModalBtn = document.getElementById("openModalBtn");
        const closeModalBtn = document.getElementById("closeModalBtn");
        const formModal = document.getElementById("formModal");
        const contactForm = document.getElementById("contactForm");
        const currencySelect = document.getElementById("currency");
        const currencies = [
            { code: "", name: "Select Currency" },
            { code: "USD", name: "United States Dollar" },
            { code: "EUR", name: "Euro" },
            { code: "JPY", name: "Japanese Yen" },
            { code: "GBP", name: "British Pound Sterling" },
            { code: "AUD", name: "Australian Dollar" },
            { code: "CAD", name: "Canadian Dollar" },
            { code: "CHF", name: "Swiss Franc" },
            { code: "CNY", name: "Renminbi (Chinese Yuan)" },
            { code: "INR", name: "Indian Rupee" },
            { code: "NGN", name: "Nigerian Naira" },
            { code: "GHS", name: "Ghanaian Cedi" },
            { code: "ZAR", name: "South African Rand" },
            { code: "KES", name: "Kenyan Shilling" },
            { code: "XOF", name: "West African CFA Franc" },
            { code: "XAF", name: "Central African CFA Franc" },
        ];

        currencies.forEach(currency => {
            const option = document.createElement("option");
            option.value = currency.code;
            option.textContent = currency.code ? `${currency.code} — ${currency.name}` : currency.name;
            currencySelect.appendChild(option);
        });
        document.addEventListener("DOMContentLoaded", () => { 
            // Enable searchable select
            if (!currencySelect.tomselect) {
                new TomSelect("#currency", {
                    create: false,
                    sortField: { field: "text", direction: "asc" }
                });
            }
        });

        // Open modal
        openModalBtn.addEventListener("click", () => {
            formModal.classList.remove("hidden");
        });

        // Close modal
        closeModalBtn.addEventListener("click", () => {
            formModal.classList.add("hidden");
        });

        // Close when clicking outside modal
        formModal.addEventListener("click", (e) => {
            if (e.target === formModal) {
                formModal.classList.add("hidden");
            }
        });

        // Handle form submit
        contactForm.addEventListener("submit", (e) => {
            e.preventDefault();
            
            const form = e.target;
            const name = form.name.value;
            const amount = form.amount.value;
            const referenceNumber = form.referenceNumber.value;
            const method = form.method.value;
            const reason = form.message.value;
            const currency = form.currency.value;
            //validate input
            if (!name || !referenceNumber || !amount || !method || !reason || !currency) {
                showToast("All fields are required.", "error");
            }else{
                const formData = new FormData();
                formData.append('fullname', name);
                formData.append('referenceNumber', referenceNumber);
                formData.append('amount', amount);
                formData.append('method', method);
                formData.append('reason', reason);
                formData.append('currency', currency);
                fetch('{{ route("refund.store") }}', {
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                    },
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if(data.status === "success"){
                        showToast("Refund Created Successfully", "success");
                        formModal.classList.add("hidden");
                    }else{
                        showToast(data.message || "An error occurred.", "error");
                        console.log(data);
                    }
                })
                .catch(error => {
                    console.log(error);
                    showToast("Request failed. Please try again.", "error");
                })
            }

        });

        //copy function
        document.addEventListener('click', function (e) {
            if (e.target.closest('[aria-label="Copy transaction reference number"]')) {
                const button = e.target.closest('button');
                const reference = button.previousElementSibling.textContent.trim();

                navigator.clipboard.writeText(reference)
                    .then(() => {
                        showToast("Reference number copied!", "success");
                    })
                    .catch(() => {
                        showToast("Failed to copy reference number.", "error");
                    });
            }
        });


        document.addEventListener("DOMContentLoaded", function () {
            const approval_status = document.querySelectorAll(".approval-status");
            approval_status.forEach(select => {
                select.addEventListener("change", () => {
                    const refundId = select.dataset.id;
                    const newStatus = select.value;
                    if (!newStatus) return;
                    // console.log(refundId);
                    Swal.fire({
                        title: 'Are you sure?',
                        text: `You are about to mark this refund as "${newStatus}".`,
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Yes, proceed',
                        cancelButtonText: 'Cancel'
                    }).then((result) => {
                        if(result.isConfirmed){
                            const formData = new FormData();
                            formData.append("status", newStatus);
                            fetch(`/refunds/${refundId}/status`, {
                                method: 'POST',
                                headers: {
                                    'Accept': 'application/json',
                                    'X-Requested-With': 'XMLHttpRequest',
                                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
                                },
                                body: formData
                            })
                            .then(response => response.json())
                            .then(data => {
                                if(data.status === "success"){
                                    showToast(data.message || "Request submitted", "success");
                                }else{
                                    showToast(data.message || "An error occured.", "error");
                                    console.log(data);
                                }
                            })
                            .catch(error => {
                                console.error(error);
                                showToast("An error Occured.", "error");
                            });
                        }else{
                            //reset the select option
                            select.value = "";
                        }
                    });
                });
            });
        });
    </script>


    <script src="https://cdn.jsdelivr.net/npm/tom-select/dist/js/tom-select.complete.min.js"></script>

</body>

</html>