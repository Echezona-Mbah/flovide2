<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Currency extends Model
{
    protected $fillable = [
        'code',
        'currency_code',
        'name',
        'country_name',
        'symbol',
        'country_code',
        'min_amount',
        'max_amount',
        'is_active',
        'collection_fee',

    ];

    protected $casts = [
        'min_amount' => 'decimal:2',
        'max_amount' => 'decimal:2',
        'collection_fee' => 'decimal:2',
        'is_active' => 'boolean',
    ];

    public function ratesFrom()
    {
        return $this->hasMany(ExchangeRate::class, 'from_currency_id');
    }

    public function ratesTo()
    {
        return $this->hasMany(ExchangeRate::class, 'to_currency_id');
    }
}
