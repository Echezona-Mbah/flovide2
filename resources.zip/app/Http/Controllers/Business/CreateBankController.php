<?php

namespace App\Http\Controllers\Business;

use App\Http\Controllers\Controller;
use App\Models\Countries;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Models\Balance;
use App\Traits\CurrencyHelper;
use Illuminate\Support\Facades\Auth;


class CreateBankController extends Controller
{
      use CurrencyHelper;

    public function create(Request $request)
    {
        $countries = Countries::all();
        $user = auth()->user();
        $balances = Balance::where('user_id', $user->id)->get();


        // Add currency meta if balances exist
        foreach ($balances as $balance) {
            $balance->currency_meta = $this->getCountryCodeFromCurrency($balance->currency);
        }

        // If API request
        if ($request->expectsJson()) {
            if ($balances->isEmpty()) {
                return response()->json([
                    'message' => 'No balance created for this user',
                    'success' => false,
                    'data' => [
                        'countries' => $countries,
                        'balances' => [],
                    ],
                    'method' => $request->method(),
                    'url' => $request->fullUrl()
                ], 200);
            }

            return response()->json([
                'message' => 'Data for add bank form loaded successfully',
                'success' => true,
                'data' => [
                    'countries' => $countries,
                    'balances' => $balances
                ],
                'method' => $request->method(),
                'url' => $request->fullUrl()
            ], 200);
        }

        return view('business.add_bank', compact('countries', 'balances'));
    }


    public function createBalance(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
            'currency' => 'required|string',
        ]);

        $userId = Auth::id() ?? $request->user_id;
           $currency   = strtoupper($request->currency);

    // 🔎 Check if user already has money in any balance
    $hasMoney = Balance::where('user_id', $userId)
        ->where('amount', '>', 0)
        ->exists();

    if (!$hasMoney) { // ❌ Block if no funds exist
        $errorMessage = 'You must have funds in at least one balance before creating a new one';

        return $request->expectsJson()
            ? response()->json([
                'data' => [
                    'status' => 'error',
                    'errors' => $errorMessage
                ]
            ], 400)
            : redirect()->back()->withErrors(['message' => $errorMessage]);
    }

    // 🔎 Check if user already has this currency
    $exists = Balance::where('user_id', $userId)
        ->where('currency', $currency)
        ->exists();

    if ($exists) {
        $errorMessage = "You already have a $currency balance. Duplicates are not allowed.";

        return $request->expectsJson()
            ? response()->json([
                'data' => [
                    'status' => 'error',
                    'errors' => $errorMessage
                ]
            ], 400)
            : redirect()->back()->withErrors(['message' => $errorMessage]);
    }

        $balance = Balance::create([
            'user_id' => $userId,
            'name' => $request->name,
            'currency' => $request->currency,
            'balance' => 0,
        ]);
        if ($request->expectsJson()) {
            return response()->json([
                'status' => true,
                'message' => 'Balance created successfully.',
                'data' => $balance
            ], 201);
        }

        return redirect()->route('add_account.create')->with('success', 'Account created successfully.');
    }



    public function getUserTotalBalance(Request $request)
    {
        $user = auth()->user();

        $total = Balance::where('user_id', $user->id)->sum('amount');

        if ($request->expectsJson()) {
            return response()->json([
                'message' => 'User total balance fetched successfully',
                'success' => true,
                'user_id' => $user->id,
                'total_balance' => $total,
                'method' => $request->method(),
                'url' => $request->fullUrl()
            ], 200);
        }

        return view('business.user_balance_total', [
            'total' => $total
        ]);
    }



    public function UpdateBalance(Request $request)
    {
        $request->validate([
            'balance_id' => 'required', 
            'name' => 'required|string|max:255',
        ]);

        $balanceId = $request->input('balance_id');
        $newName = $request->input('name');

        $balance = Balance::where('id', $balanceId)->first();

        if (!$balance) {
            return $request->expectsJson()
                ? response()->json(['message' => 'Balance not found.'], 404)
                : redirect()->back()->with('error', 'Balance not found.');
        }

        $balance->name = $newName;
        $balance->save();

        if ($request->expectsJson()) {
            return response()->json([
                'message' => 'Balance updated successfully.',
                'data' => $balance,
                'method' => $request->method(),
                'url' => $request->fullUrl()
            ], 200);
        }

        return redirect()->back()->with('success', 'Balance updated successfully.');
    }

    public function index(Request $request)
        {
            $balances = Balance::all(); // Eager load user if needed

            if ($request->expectsJson()) {
                return response()->json([
                    'message' => 'All balances retrieved successfully',
                    'success' => true,
                    'data' => $balances,
                    'method' => $request->method(),
                    'url' => $request->fullUrl(),
                ], 200);
            }

            return view('business.all_balances', compact('balances'));
        }



    public function dashboardapi(Request $request)
{
    $account = Auth::user();

    if (!$account) {
        return response()->json([
            'success' => false,
            'message' => 'Unauthenticated'
        ], 401);
    }

    $balances = \App\Models\Balance::where('user_id', $account->id)->get();
    $transactions = \App\Models\TransactionHistory::where('user_id', $account->id)
        ->latest()
        ->take(4)
        ->get()
        ->map(function ($t) {
            return [
                'type'      => $t->type,
                'date'      => $t->created_at->format('Y-m-d H:i:s'),
                'sender'    => $t->sender ?? 'N/A',
                'recipient' => $t->recipient ?? 'N/A',
                'amount'    => $t->currency_symbol . number_format($t->amount, 2),
                'currency'  => $t->currency,
                'status'    => $t->status,
                'reference' => $t->reference,
                'recipient_details' => [
                    'alias'          => $t->recipient_alias,
                    'account_name'   => $t->recipient_account_name,
                    'account_number' => $t->recipient_account_number,
                    'bank_name'      => $t->recipient_bank_name,
                    'bank_currency'  => $t->recipient_bank_currency,
                ]
            ];
        });


    // -------------------------
    // 3️⃣ CHART DATA (LAST 3 MONTHS)
    // -------------------------
    $months = collect(range(0, 2))->map(function ($i) {
        return now()->subMonths($i)->format('Y-m');
    })->reverse()->values();

    $dbData = \App\Models\TransactionHistory::where('user_id', $account->id)
        ->where('created_at', '>=', now()->subMonths(3))
        ->selectRaw("DATE_FORMAT(created_at, '%Y-%m') as month, SUM(amount) as total_amount")
        ->groupByRaw("DATE_FORMAT(created_at, '%Y-%m')")
        ->pluck('total_amount', 'month');

    $chartData = $months->map(function ($m) use ($dbData) {
        return [
            'month' => $m,
            'total_amount' => $dbData[$m] ?? 0,
        ];
    });


    // -------------------------
    // 4️⃣ RETURN JSON FOR API
    // -------------------------
    if ($request->expectsJson()) {
        return response()->json([
            'success' => true,
            'message' => 'Dashboard data fetched successfully',
            'data' => [
                'balances'     => $balances,
                'chart_data'   => $chartData,
                'recent_history' => $transactions,
            ]
        ], 200);
    }

    // -------------------------
    // 5️⃣ RETURN WEB VIEW
    // -------------------------
    return view('dashboard.index', [
        'balances' => $balances,
        'chartData' => $chartData,
        'transactions' => $transactions,
    ]);
}

    
    
    





    
}
