<?php

namespace App\Http\Controllers\Business;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Models\Invoices;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Support\Carbon;

class InvoicesController extends Controller
{
    //
    public function index(Request $request)
    {
        $user = Auth::user();
        
        $invoices = Invoices::with('items')->where('user_id', $user->id)
            ->latest()
            ->paginate(10);

        if ($request->expectsJson()) {
            if ($invoices->isEmpty()) {
                return response()->json([
                    'data' => [
                        'status' => 'success',
                        'message' => 'No invoices found for this user.',
                        'invoices' => $invoices
                    ]
                ], 200);
            }

            return response()->json([
                'data' => [
                    'status' => 'success',
                    'message' => 'All user invoices successfully listed.',
                    'invoices' => $invoices
                ]
            ], 200);
        }
        
        return view('business.invoicesList', compact('invoices'));
        
    }

    public function create()
    {
        // return create page view
        return view('business.createInvoice');
    }

    private function generateTrackingCode(): string
    {
        do {
            $code = 'INV-' . now()->format('Ymd') . '-' . strtoupper(Str::random(10));
        } while (Invoices::where('tracking_code', $code)->exists());

        return $code;
    }


    public function store(Request $request)
    {
        //    dd($request->all());
        // Validate the request
        $validated = $request->validate([
            'invoice_number' => 'required|unique:invoices',
            'billed_to' => 'required|string',
            'due_date' => 'required|date',
            'address' => 'nullable|string',
            'currency' => 'required|string|max:10',
            'note' => 'nullable|string',
            'amount' => 'required|numeric|min:0',
            'status' => 'required|in:draft,pending',
            'items' => 'required|array|min:1',
            'items.*.item_name' => 'required|string',
            'items.*.qty' => 'required|integer|min:1',
            'items.*.rate_enabled' => 'required|boolean',
            'items.*.rate' => 'nullable|numeric',
            'items.*.total' => 'required|numeric',
        ]);

        // Generate a unique tracking code
        $trackingCode = $this->generateTrackingCode();

        $invoiceReceiptLink = url('/invoices/receipts/' . $trackingCode);

        $invoice = Invoices::create([
            'user_id' => Auth::id(),
            'invoice_number' => $validated['invoice_number'],
            'tracking_code' => $trackingCode,
            'billed_to' => $validated['billed_to'],
            'address' => $validated['address'] ?? null,
            'due_date' => $validated['due_date'],
            'currency' => $validated['currency'],
            'note' => $validated['note'] ?? null,
            'amount' => $validated['amount'],
            'status' => $validated['status'],
            'invoice_receipt_link' => $invoiceReceiptLink
        ]);

        foreach ($validated['items'] as $item) {
            $invoice->items()->create([
                'item_name' => $item['item_name'],
                'qty' => $item['qty'],
                'rate' => $item['rate_enabled'] ? $item['rate'] : null,
                'total' => $item['total'],
                'rate_enabled' => $item['rate_enabled'],
            ]);
        }

        return response()->json([
            'data' => [
                'status' => 'success',
                'message' => 'Invoice created successfully.',
                'invoice_id' => $invoice->id
            ]
        ], 200);
    }

    public function show($id)
    {
        // $invoice = Invoices::with(['items'])->findOrFail($id);
        $invoice = Invoices::with('items')->where('id', $id)->first();

        if (!$invoice) {
            // handle not found case
            return response()->json([
                'data' => [
                    'status' => 'error',
                    'message' => 'Invoice not found.'
                ]
            ], 404);
        }

        // Check if the user owns the invoice
        if ($invoice->user_id !== Auth::id()) {
            return response()->json([
                'data' => [
                    'status' => 'error',
                    'message' => 'Unauthorized'
                ]
            ], 403);
        }

        //success response
        return response()->json([
            'data' => [
                'status' => 'success',
                'message' => 'Invoice details retrieved successfully.',
                'invoice' => $invoice
            ]
        ], 200);
    }

    public function update(Request $request, $id)
    {
        //check if the user owns the invoice
        $invoice = Invoices::with('items')->findOrFail($id); 
        if ($invoice->user_id !== Auth::id()) {
            if ($request->expectsJson()) {
                return response()->json([
                    'data' => [
                        'status' => 'error',
                        'message' => 'Unauthorized'
                    ]
                ], 403);
            }
            abort(403, 'Unauthorized');
        }

        $validated = $request->validate([
            'invoice_number' => 'sometimes|string',
            'billed_to' => 'sometimes|string',
            'due_date' => 'sometimes|date',
            'address' => 'sometimes|string|nullable',
            'currency' => 'sometimes|string',
            'note' => 'sometimes|string|nullable',
            'amount' => 'required|numeric|min:0',
            'status' => 'sometimes|in:pending,draft',
            'items' => 'sometimes|array|min:1',
            'items.*.id' => 'nullable|integer',
            'items.*.item_name' => 'required|string',
            'items.*.qty' => 'required|numeric|min:1',
            'items.*.rate_enabled' => 'required|boolean',
            'items.*.rate' => 'nullable|numeric|min:0',
            'items.*.total' => 'required|numeric|min:0',
        ]);

        // Track changes
        $original = $invoice->toArray();
        $changes = [];

        $fieldsToCompare = ['invoice_number', 'billed_to', 'due_date', 'address', 'currency', 'note', 'status'];

        foreach ($fieldsToCompare as $field) {
            if (isset($validated[$field]) && $validated[$field] != $invoice->$field) {
                $changes[$field] = [
                    'old' => $invoice->$field,
                    'new' => $validated[$field]
                ];
                $invoice->$field = $validated[$field];
            }
        }

        // Recalculate total amount
        $totalAmount = collect($validated['items'])->sum('total');
        if ($invoice->amount != $totalAmount) {
            $changes['amount'] = [
                'old' => $invoice->amount,
                'new' => $totalAmount
            ];
            $invoice->amount = $totalAmount;
        }

        $invoice->save();

        // Handle items update
        if (isset($validated['items'])) {
            // Track changes of items being updated
            $originalItems = $invoice->items->keyBy('id');

            // Loop through each item in the request
            foreach ($validated['items'] as $itemData) {
                if (!empty($itemData['id']) && isset($originalItems[$itemData['id']])) {
                    $item = $originalItems[$itemData['id']];
                    $itemChanged = false;

                    foreach (['item_name', 'qty', 'rate_enabled', 'rate', 'total'] as $field) {
                        if ($item->$field != $itemData[$field]) {
                            $itemChanged = true;
                            $changes["item_{$item->id}_$field"] = [
                                'old' => $item->$field,
                                'new' => $itemData[$field]
                            ];
                            $item->$field = $itemData[$field];
                        }
                    }

                    if ($itemChanged) {
                        $item->save();
                    }
                } else {
                    // New item
                    $invoice->items()->create($itemData);
                    $changes['new_item'][] = $itemData;
                }
            }

            // $invoice->load('items');

            $existingIds = $originalItems->keys()->all();
            $updatedIds = collect($validated['items'])->pluck('id')->filter()->all();

            $deletedIds = array_diff($existingIds, $updatedIds);
            if (!empty($deletedIds)) {
                $deletedItems = $invoice->items()->whereIn('id', $deletedIds)->get();
                foreach ($deletedItems as $deletedItem) {
                    $changes['deleted_item'][] = $deletedItem->toArray();
                    $deletedItem->delete();
                }
            }
        }

        return response()->json([
            'data' => [
                'status' => 'success',
                'message' => 'Invoice updated successfully',
                'invoice' => $invoice->fresh('items'),
                'changes' => $changes
            ]
        ], 200);
    }


    public function edit(Request $request, $id)
    {
        $invoice = Invoices::with('items')->findOrFail($id);

        //check if the user owns the invoice
        if ($invoice->user_id !== Auth::id()) {
            if ($request->expectsJson()) {
                return response()->json(['message' => 'Unauthorized'], 403);
            }
            abort(403, 'Unauthorized');
        }

        // Transform invoice items for frontend use
        $invoiceItems = $invoice->items->map(function ($item) {
            return [
                'id' => $item->id,
                'item_name' => $item->item_name,
                'qty' => (int) $item->qty,
                'rate_enabled' => (bool) $item->rate_enabled,
                'rate' => $item->rate_enabled ? (float) $item->rate : null,
                'total' => (float) $item->total,
            ];
        });

        // If it's an API request, return JSON data
        if (request()->expectsJson()) {
            return response()->json([
                'invoice' => $invoice,
                'items' => $invoiceItems,
            ]);
        }
        // Otherwise, return the edit view
        return view('business.editInvoice', compact('invoice', 'invoiceItems'));
    }


    public function destroy(Request $request, $id)
    {
        $invoice = Invoices::findOrFail($id);

        if ($invoice->user_id !== Auth::id()) {
            if ($request->expectsJson()) {
                return response()->json([
                    'data' => [
                        'status' => 'error',
                        'message' => 'Unauthorized'
                    ]
                ], 403);
            }
            abort(403, 'Unauthorized');
        }

        $invoice->delete(); // Soft delete

        if ($request->expectsJson()) {
            return response()->json([
                'data' => [
                    'status' => 'success',
                    'message' => 'Invoice deleted successfully.'
                ]
            ], 200);
        }

        return redirect()->back()->with('success', 'Invoice deleted successfully.');
    }

    public function showReceipt(Request $request, $tracking_code)
    {
        $invoice = Invoices::with('items')->where('tracking_code', $tracking_code)->first();

        if (!$invoice) {
            if($request->expectsJson()){
                return response()->json([
                    'data' => [
                        'status' => 'error',
                        'message' => 'Invoice not found.'
                    ]
                ], 404);
            }
            return abort(404, 'Invoice not found.');
        }

        if($request->expectsJson()){
            return response()->json([
                'data' => [
                    'status' => 'success',
                    'invoice' => $invoice
                ]
            ], 200);
        }

        // Return the invoice receipt view
        return view('business.invoiceReceipt', compact('invoice'));
    }
}
