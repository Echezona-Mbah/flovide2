@include('business.head')
<body class="bg-[#E9E9E9]  text-[#1E1E1E] min-h-screen flex flex-col md:flex-row">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Mobile menu button -->
  @include('business.header')

    <!-- Sidebar -->
   @include('business.sidebar')
  <!-- Overlay -->
  <div id="overlay" class="fixed inset-0 bg-black bg-opacity-30 z-20 hidden md:hidden"></div>
  <!-- Main content -->
  <main class="flex-1 p-2 md:p-8 overflow-auto ml-0 md:ml-0">
    <header class="items-center justify-between mb-8 flex-wrap gap-4 hidden md:flex">
      <h1 class="text-2xl font-extrabold leading-tight flex-1 min-w-[200px]">
        Dashboard
      </h1>
                  @include('business.header_notifical')

    </header>
    <section class="relative w-full">
    
        <section
  class="bg-white text-gray-700 min-h-screen md:w-[80vw] md:rounded-tl-3xl md:p-6 p-2 shadow-md md:absolute right-[-2vw] overflow-x-hidden">
  <section class="w-full flex flex-col md:flex-row min-h-screen">
    <!-- Left side: Table and filters -->
    <div class="w-full px-4 sm:px-6 lg:px-8 pt-8">
      <!-- Navigation -->
      <nav class="border-b border-gray-200 mb-6">
        <ul class="flex space-x-8 text-sm font-medium text-gray-600">
             <li>
            <a href="{{ route('organization') }}" aria-current="page" class="text-black border-b-2 border-black pb-3 block">
                Team Members
            </a>
            </li>
            <li>
            <a href="{{ route('organization_setting') }}" class="hover:text-gray-900 block">
                Settings
            </a>
            </li>
            <li>
            <a href="{{ route('organization_plan') }}" class="hover:text-gray-900 block">
                Subscription plan
            </a>
            </li>

        </ul>
      </nav>
      <!-- Search and New Member -->
      <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 gap-4 sm:gap-0">
        <div class="flex-1 max-w-xs">
          <label class="sr-only" for="search"> Search team </label>
          <div class="relative text-gray-400 focus-within:text-gray-600">
            <span class="absolute inset-y-0 left-0 flex items-center pl-3">
              <i class="fas fa-search"> </i>
            </span>
            <input
              class="block w-full rounded-lg border border-gray-300 py-2 pl-10 pr-3 text-sm placeholder-gray-400 focus:border-blue-400 focus:ring-1 focus:ring-blue-400 focus:outline-none"
              id="search" name="search" placeholder="Search team" type="search" />
          </div>
        </div>
        <button
          class="inline-flex items-center justify-center rounded-full border border-blue-300 bg-blue-100 px-4 py-2 text-sm font-medium text-blue-800 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
          type="button">
          <i class="fas fa-plus mr-2"> </i>
          New Member
        </button>
      </div>
      <!-- Table -->
      <section class="w-full overflow-x-auto">
        <table
          class="w-full mt-6 text-sm text-left text-gray-700 border-separate border-spacing-y-3 max-w-[900px] md:max-w-[90vw]">
          <thead class="bg-white">
            <tr>
              <th class="whitespace-nowrap px-4 py-3 text-left font-semibold text-gray-500" scope="col">
                Member
              </th>
              <th class="whitespace-nowrap px-4 py-3 text-left font-semibold text-gray-500" scope="col">
                Email
              </th>
              <th class="whitespace-nowrap px-4 py-3 text-left font-semibold text-gray-500" scope="col">
                Date Added
              </th>
              <th class="whitespace-nowrap px-4 py-3 text-left font-semibold text-gray-500" scope="col">
                Role
              </th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-100 w-full">
             
                  <!-- Row 1 -->
                  <tr>
                    <td class="whitespace-nowrap px-4 py-5 flex items-center  gap-3">
                      <label
                        class="relative cursor-pointer flex items-center justify-center w-5 h-5 rounded-full border-2 border-gray-900"
                        for="owner">
                        <input checked=""
                          class="appearance-none w-5 h-5 rounded-full border-2 border-gray-900 checked:bg-gray-900 checked:border-gray-900 focus:outline-none"
                          id="owner" name="team-member" type="radio" />
                        <span class="pointer-events-none absolute w-3.5 h-3.5 rounded-full bg-white">
                        </span>
                      </label>
                      <span class="font-semibold text-gray-900">
                        Nexus Global
                      </span>
                    </td>
                    <td class="whitespace-nowrap px-4 py-5 font-semibold text-gray-900">
                      nexg@gmail.com
                    </td>
                    <td class="whitespace-nowrap px-4 py-5 font-semibold text-gray-900">
                      Aug 6, 2025
                    </td>
                    <td class="whitespace-nowrap px-4 py-5">
                      <select aria-label="Role for Nexus Global"
                        class="rounded-lg border border-gray-300 py-2 px-3 text-gray-400 cursor-not-allowed"
                        disabled="">
                        <option>Owner</option>
                        <option>Admin</option>
                        <option>Accountant</option>
                        <option>Author</option>
                      </select>
                    </td>
                  </tr>
                  <!-- Row 2 -->
                  <tr>
                    <td class="whitespace-nowrap px-4 py-5 flex items-center gap-3">
                      <img alt="Photo of Jenny Wilson, a woman with long dark hair and glasses, smiling"
                        class="w-6 h-6 rounded-full object-cover" height="24"
                        src="https://storage.googleapis.com/a1aa/image/9a1ce957-a4ae-408d-fa68-bccca97d50c7.jpg"
                        width="24" />
                      <span class="font-semibold text-gray-900">
                        Jenny Wilson
                      </span>
                    </td>
                    <td class="whitespace-nowrap px-4 py-5 text-gray-900">
                      jenny@gmail.com
                    </td>
                    <td class="whitespace-nowrap px-4 py-5 font-semibold text-gray-900">
                      Aug 6, 2025
                    </td>
                    <td class="whitespace-nowrap px-4 py-5">
                      <select aria-label="Role for Jenny Wilson"
                        class="rounded-lg border border-gray-300 py-2 px-3 text-gray-900">
                        <option>Owner</option>
                        <option selected="">Admin</option>
                        <option>Accountant</option>
                        <option>Author</option>
                      </select>
                    </td>
                  </tr>
                  <!-- Row 3 -->
                  <tr>
                    <td class="whitespace-nowrap px-4 py-5 flex flex-col gap-0.5">
                      <div class="flex items-center gap-3">
                        <img alt="Photo of Cody Fisher, a man with dark hair and beard, smiling"
                          class="w-6 h-6 rounded-full object-cover" height="24"
                          src="https://storage.googleapis.com/a1aa/image/7e20d043-8827-4910-8cec-bd540bd2472b.jpg"
                          width="24" />
                        <span class="text-gray-400 font-semibold">
                          Cody Fisher
                        </span>
                      </div>
                      <span class="text-xs text-red-600 font-semibold -mt-1 ml-9">
                        Pending
                      </span>
                    </td>
                    <td class="whitespace-nowrap px-4 py-5 font-semibold text-gray-900">
                      cf@gmail.com
                    </td>
                    <td class="whitespace-nowrap px-4 py-5 font-semibold text-gray-900">
                      Aug 6, 2025
                    </td>
                    <td class="whitespace-nowrap px-4 py-5">
                      <select aria-label="Role for Cody Fisher"
                        class="rounded-lg border border-gray-300 py-2 px-3 text-gray-900">
                        <option>Owner</option>
                        <option>Admin</option>
                        <option selected="">Accountant</option>
                        <option>Author</option>
                      </select>
                    </td>
                  </tr>
                  <!-- Row 4 -->
                  <tr>
                    <td class="whitespace-nowrap px-4 py-5 flex items-center gap-3">
                      <img alt="Photo of Jacob Jones, a man with glasses and beard, smiling"
                        class="w-6 h-6 rounded-full object-cover" height="24"
                        src="https://storage.googleapis.com/a1aa/image/4b606c05-bd80-4079-a9ff-bc1d60428c5c.jpg"
                        width="24" />
                      <span class="font-semibold text-gray-900">
                        Jacob Jones
                      </span>
                    </td>
                    <td class="whitespace-nowrap px-4 py-5 text-gray-900">
                      jj@gmail.com
                    </td>
                    <td class="whitespace-nowrap px-4 py-5 font-semibold text-gray-900">
                      Aug 6, 2025
                    </td>
                    <td class="whitespace-nowrap px-4 py-5 relative">
                      <select aria-label="Role for Jacob Jones"
                        class="rounded-lg border border-gray-300 py-2 px-3 text-gray-900">
                        <option>Owner</option>
                        <option>Admin</option>
                        <option>Accountant</option>
                        <option selected="">Author</option>
                      </select>
                      <div
                        class="absolute top-full right-0 mt-1 w-full max-w-xs rounded-b-lg border border-t-0 border-gray-300 bg-white shadow-lg z-10 hidden">
                        <ul>
                          <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer">
                            Owner
                          </li>
                          <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer">
                            Admin
                          </li>
                          <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer">
                            Accountant
                          </li>
                          <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer">
                            Author
                          </li>
                        </ul>
                      </div>
                    </td>
                  </tr>
              
          </tbody>
        </table>
      </section>
    </div>
  </section>
</section>

        <!-- modal -->

        <section
          class="fixed inset-0 z-50 flex items-center justify-center bg-[#FFFFFF66] drop-shadow-sm backdrop-blur-sm bg-opacity-50"
          id="modal" style="display: none">
          <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
            <div class="flex justify-between w-full items-center border-b pb-4 mb-4">
              <p class="text-xl font-semibold mb-4">Add a New Member</p>

              <button class="border h-6 w-6 rounded-md flex items-center justify-center">
                <i class="fas fa-times text-md cursor-pointer text-[#828282]"></i>
              </button>
            </div>
            <form class="space-y-6">
           
              <div class="mb-4">
                <label class="flex flex-col text-[#828282] text-md gap-1">
                  Email
                  <input type="email" class="border border-gray-300 p-2 rounded-lg text-black focus:outline-none focus:ring-1 focus:ring-blue-300 placeholder:text-[#D7D4D5]"
                    placeholder="john@gmail.com" required />
                </label>
              </div>
              <div class="mb-4">
                <label class="flex flex-col text-[#828282] text-md gap-1">
                  Notes (optional)
                  <select aria-label="Role for Jacob Jones"
                        class="rounded-lg border border-gray-300 py-2 px-3 text-gray-900">
                        <option>Owner</option>
                        <option>Admin</option>
                        <option>Accountant</option>
                        <option selected="">Author</option>
                      </select>

                        <div
                        class="absolute top-full right-0 mt-1 w-full max-w-xs rounded-b-lg border border-t-0 border-gray-300 bg-white shadow-lg z-10 hidden">
                        <ul>
                          <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer">
                            Owner
                          </li>
                          <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer">
                            Admin
                          </li>
                          <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer">
                            Accountant
                          </li>
                          <li class="px-4 py-2 hover:bg-gray-100 cursor-pointer">
                            Author
                          </li>
                        </ul>
                      </div>
                </label>
              </div>

              <button type="submit" class="w-full bg-[#215F9C] text-white font-semibold py-2 px-4 rounded-2xl">
                Add Member
              </button>
            </form>
          </div>
        </section>
        <!-- modal end-->
      </section>
    </section>
  </main>
  <script>
    const sidebar = document.getElementById("sidebar");
    const openBtn = document.getElementById("openSidebarBtn");
    const closeBtn = document.getElementById("closeSidebarBtn");
    const overlay = document.getElementById("overlay");

    function openSidebar() {
      sidebar.classList.remove("-translate-x-full");
      overlay.classList.remove("hidden");
      document.body.style.overflow = "hidden";
    }

    function closeSidebar() {
      sidebar.classList.add("-translate-x-full");
      overlay.classList.add("hidden");
      document.body.style.overflow = "";
    }

    openBtn.addEventListener("click", openSidebar);
    closeBtn.addEventListener("click", closeSidebar);
    overlay.addEventListener("click", closeSidebar);

    // Close sidebar on window resize if desktop
    window.addEventListener("resize", () => {
      if (window.innerWidth >= 768) {
        sidebar.classList.remove("-translate-x-full");
        overlay.classList.add("hidden");
        document.body.style.overflow = "";
      } else {
        sidebar.classList.add("-translate-x-full");
      }
    });

    document.addEventListener("DOMContentLoaded", function () {
      // Get modal element
      const modal = document.getElementById("modal");

      // Get "Create Virtual Card" button
      const createBtn = document.querySelectorAll("button");
      createBtn.forEach((btn) => {
        if (btn.textContent.trim() === "New Member") {
          btn.addEventListener("click", function () {
            modal.style.display = "flex"; // Show modal
          });
        }
      });

      // Get Close button (the one with the 'fa-times' icon)
      const closeBtn = modal.querySelector(".fa-times");
      closeBtn.addEventListener("click", function () {
        modal.style.display = "none"; // Hide modal
      });

      // Optional: Hide modal on page load
      modal.style.display = "none";
    });
  </script>
</body>

</html>