@include('business.head')
<body class="bg-[#E9E9E9]  text-[#1E1E1E] min-h-screen flex flex-col md:flex-row">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Mobile menu button -->
  @include('business.header')

    <!-- Sidebar -->
   @include('business.sidebar')
    <!-- Overlay -->
    <div id="overlay" class="fixed inset-0 bg-black bg-opacity-30 z-20 hidden md:hidden"></div>
    <!-- Main content -->
    <main class="flex-1 p-2 md:p-8 overflow-auto ml-0 md:ml-0">
        <header class=" items-center justify-between mb-8 flex-wrap gap-4 hidden md:flex">
            <h1 class="text-2xl font-extrabold leading-tight flex-1 min-w-[200px]">
                Dashboard
            </h1>
                       @include('business.header_notifical')

        </header>
        <section class=" relative w-full ">
            <section
                class="bg-white text-gray-700 min-h-screen md:w-[80vw]   md:rounded-tl-3xl md:p-6 p-2 shadow-md md:absolute right-[-2vw] overflow-x-hidden ">


                <div class=" mx-auto space-y-4">
    <!-- Item 1 -->
    <div
      class="flex  items-center justify-between border border-gray-300 rounded-xl p-4"
    >
      <div class="flex items-center space-x-4">
        <div
          class="flex items-center justify-center w-8 h-8 rounded-full border border-green-400 text-green-500"
        >
          <i class="fas fa-check"></i>
        </div>
        <p class="font-semibold text-gray-900 text-sm leading-5">
          CAC certificate
        </p>
      </div>
      <div class="flex flex-col md:flex-row items-center space-y-4 md:space-x-20">
        <div
          class="text-green-700 bg-green-200 rounded-full px-3 py-0.5 text-xs font-semibold select-none"
        >
          Confirmed
        </div>
        <button
          class="text-gray-900 text-sm font-normal border border-gray-300 rounded-lg px-5 py-2 hover:bg-gray-50"
        >
          Download
        </button>
      </div>
    </div>

    <!-- Item 2 -->
    <div
      class="flex items-center justify-between border border-gray-300 rounded-xl p-4"
    >
      <div class="flex items-center space-x-4">
        <div
          class="flex items-center justify-center w-8 h-8 rounded-full border border-gray-300 text-gray-500"
        >
          <i class="fas fa-file-alt"></i>
        </div>
        <p class="font-semibold text-gray-900 text-sm leading-5">
          Bank Verification Number (BVN)
        </p>
      </div>
        <div class="flex flex-col md:flex-row items-center space-y-4 md:space-x-20">
        <div
          class="text-gray-700 bg-gray-300 rounded-full w-24 px-2 py-0.5 text-xs font-semibold select-none"
        >
          Not submitted
        </div>
        <button
          class="text-gray-900 text-sm font-normal border border-gray-300 rounded-lg px-5 py-2 hover:bg-gray-50"
        >
          Add
        </button>
      </div>
    </div>

    <!-- Item 3 -->
    <div
      class="flex items-center justify-between border border-gray-300 rounded-xl p-4"
    >
      <div class="flex items-center space-x-4">
        <div
          class="flex items-center justify-center w-8 h-8 rounded-full border border-yellow-300 text-yellow-400"
        >
          <i class="fas fa-bookmark"></i>
        </div>
        <p class="font-semibold text-gray-900 text-sm leading-5">
          Valid ID of Directors/Owners
        </p>
      </div>
  <div class="flex flex-col md:flex-row items-center space-y-4 md:space-x-20">
        <div
          class="text-yellow-700 bg-yellow-200 rounded-full px-3 py-0.5 text-xs font-semibold select-none"
        >
          Under review
        </div>
        <button
          class="text-gray-900 text-sm font-normal border border-gray-300 rounded-lg px-5 py-2 hover:bg-gray-50"
        >
          Download
        </button>
      </div>
    </div>

    <!-- Item 4 -->
    <div
      class="flex items-center justify-between border border-gray-300 rounded-xl p-4"
    >
      <div class="flex items-center space-x-4">
        <div
          class="flex items-center justify-center w-8 h-8 rounded-full border border-red-300 text-red-500"
        >
          <i class="fas fa-exclamation-triangle"></i>
        </div>
        <p class="font-semibold text-gray-900 text-sm leading-5">
          Tax Identification Number (TIN)
        </p>
      </div>
       <div class="flex flex-col md:flex-row items-center space-y-4 md:space-x-20">
        <div
          class="text-red-700 bg-red-200 rounded-full px-3 py-0.5 text-xs font-semibold select-none"
        >
          Rejected
        </div>
        <button
          class="text-gray-900 text-sm font-normal border border-gray-300 rounded-lg px-5 py-2 hover:bg-gray-50" id="uploadBtn"
        >
          Upload
        </button>
      </div>
    </div>

    <!-- Item 5 -->
    <div
      class="flex items-center justify-between border border-gray-300 rounded-xl p-4"
    >
      <div class="flex items-center space-x-4">
        <div
          class="flex items-center justify-center w-8 h-8 rounded-full border border-yellow-300 text-yellow-400"
        >
          <i class="fas fa-bookmark"></i>
        </div>
        <p class="font-semibold text-gray-900 text-sm leading-5">
          Utility Bill / Proof of Address
        </p>
      </div>
     <div class="flex flex-col md:flex-row items-center space-y-4 md:space-x-20">
        <div
          class="text-yellow-700 bg-yellow-200 rounded-full px-3 py-0.5 text-xs font-semibold select-none"
        >
          Under review
        </div>
        <button
          class="text-gray-900 text-sm font-normal border border-gray-300 rounded-lg px-5 py-2 hover:bg-gray-50"
        >
          Download
        </button>
      </div>
    </div>
  </div>


                <!-- modal upload -->
                <section
                    class="fixed inset-0 z-50 flex items-center justify-center bg-[#FFFFFF66] drop-shadow-sm backdrop-blur-sm bg-opacity-50"
                    id="modal" style="display: none;">
                    <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
                        <div class="flex justify-between w-full items-center border-b pb-4 mb-4">
                            <p class="text-xl font-semibold mb-4">CAC certificate</p>

                            <button class=" border h-6 w-6 rounded-md flex items-center justify-center ">
                                <i class="fas fa-times  text-md cursor-pointer text-[#828282]"></i>

                            </button>
                        </div>
                        <form class="space-y-5">

                           

                            <div class="mb-4">

                                <label class="flex flex-col text-[#828282] text-md gap-1">
                                 Select CAC Type
                                    <select
                                        class="border border-gray-300  p-2 rounded-2xl text-black flex items-center focus:outline-none focus:ring-1 focus:ring-blue-300">
                                        <option class="flex items-center" selected>
                                          Business Name
                                        </option>
                                    </select>
                                </label>
                            </div>

                            <div class="text-[#666666] font-normal text-sm mb-4">
                              
                              <p>Upload document <span class="text-red-500">(required)</span></p>
                              <p>PNGs, PDF and JPGs under 10MB</p>
                            </div>

                            <div class="mb-4">
                                <label class="flex flex-col text-[#828282] text-md gap-1">
                                    Upload 
                                    <input type="file"
                                        class="border border-gray-300 p-2 rounded-2xl text-black focus:outline-none focus:ring-1 focus:ring-blue-300" />
                                </label>

                                </div>

                            <button type="submit"
                                class="w-full bg-[#215F9C] text-white font-medium py-2 px-4 rounded-2xl">
                               Submit
                            </button>
                        </form>

                    </div>

                </section>
                <!-- modal end-->




                  <!--  modalBvn -->
                <section
                    class="fixed inset-0 z-50 flex items-center justify-center bg-[#FFFFFF66] drop-shadow-sm backdrop-blur-sm bg-opacity-50"
                    id="modalBvn" style="display: none;">
                    <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
                        <div class="flex justify-between w-full items-center border-b pb-4 mb-4">
                            <p class="text-xl font-semibold mb-4">Bank Verification Number (BVN)</p>

                            <button class=" border h-6 w-6 rounded-md flex items-center justify-center ">
                                <i class="fas fa-times  text-md cursor-pointer text-[#828282]"></i>

                            </button>
                        </div>
                        <form class="space-y-5">

                           

                            <div class="mb-4">

                                <label class="flex flex-col text-[#828282] text-md gap-1">
                                BVN
                                    <input type="text"
                                        class="border border-gray-300  p-2 rounded-2xl text-black flex items-center focus:outline-none focus:ring-1 focus:ring-blue-300 placeholder:text-[#E7E7E7]" placeholder="1234567812345678" />
                                        
                                    
                                </label>
                            </div>

                          

                            <button type="submit"
                                class="w-full bg-[#215F9C] text-white font-medium py-2 px-4 rounded-2xl">
                               Submit
                            </button>
                        </form>

                    </div>

                </section>
                <!-- modal end-->
            </section>

        </section>
    </main>
    <script>
        const sidebar = document.getElementById('sidebar');
        const openBtn = document.getElementById('openSidebarBtn');
        const closeBtn = document.getElementById('closeSidebarBtn');
        const overlay = document.getElementById('overlay');

        function openSidebar() {
            sidebar.classList.remove('-translate-x-full');
            overlay.classList.remove('hidden');
            document.body.style.overflow = 'hidden';
        }

        function closeSidebar() {
            sidebar.classList.add('-translate-x-full');
            overlay.classList.add('hidden');
            document.body.style.overflow = '';
        }

        openBtn.addEventListener('click', openSidebar);
        closeBtn.addEventListener('click', closeSidebar);
        overlay.addEventListener('click', closeSidebar);

        // Close sidebar on window resize if desktop
        window.addEventListener('resize', () => {
            if (window.innerWidth >= 768) {
                sidebar.classList.remove('-translate-x-full');
                overlay.classList.add('hidden');
                document.body.style.overflow = '';
            } else {
                sidebar.classList.add('-translate-x-full');
            }
        });






        document.addEventListener("DOMContentLoaded", function () {
            // Get modal element
            const modal = document.getElementById("modal");
                   

            // Get "Create Virtual Card" button
            const createBtn = document.querySelectorAll("button");
            createBtn.forEach((btn) => {
                if (btn.textContent.trim() === "Upload") {
                    btn.addEventListener("click", function () {
                        modal.style.display = "flex"; // Show modal
                    });
                }
            });

            // Get Close button (the one with the 'fa-times' icon)
            const closeBtn = modal.querySelector(".fa-times");
            closeBtn.addEventListener("click", function () {
                modal.style.display = "none"; // Hide modal
            });

            // Optional: Hide modal on page load
            modal.style.display = "none";
        });


        document.addEventListener("DOMContentLoaded", function () {
            // Get modal element
            const modal = document.getElementById("modalBvn");
                   

            // Get "Create Virtual Card" button
            const createBtn = document.querySelectorAll("button");
            createBtn.forEach((btn) => {
                if (btn.textContent.trim() === "Add") {
                    btn.addEventListener("click", function () {
                        modal.style.display = "flex"; // Show modal
                    });
                }
            });

            // Get Close button (the one with the 'fa-times' icon)
            const closeBtn = modal.querySelector(".fa-times");
            closeBtn.addEventListener("click", function () {
                modal.style.display = "none"; // Hide modal
            });

            // Optional: Hide modal on page load
            modal.style.display = "none";
        });
    </script>
</body>

</html>