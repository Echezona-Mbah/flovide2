<?php

namespace App\Http\Controllers\Business;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class VirtualAccountController extends Controller
{

    public function index(Request $request)
    {
    
        return view('business.add_virtualcard');
    }

    public function createVirtualAccount(Request $request)
{
    $request->validate([
        'account_name' => 'required|string',
        'currency' => 'required|string',
        'settlement_balance_id' => 'required|string',
        'reference_id' => 'required|string|unique:virtual_accounts,reference_id',
    ]);

    $payload = $request->only([
        'account_name',
        'currency',
        'settlement_balance_id',
        'reference_id'
    ]);

    dd($payload);

    $response = Http::withHeaders([
        'Authorization' => 'Bearer ' . env('OHENTPAY_API_KEY'),
        'Accept' => 'application/json',
        'Content-Type' => 'application/json',
    ])->post(env('OHENTPAY_BASE_URL') . '/virtualaccounts', $payload);

    if ($response->successful()) {
        if ($request->expectsJson()) {
            return response()->json($response->json());
        }

        return redirect()->route('add_account.create')->with('success', 'Virtual account created successfully.');
    }

    if ($request->expectsJson()) {
        return response()->json([
            'message' => 'Virtual account creation failed',
            'errors' => $response->json()
        ], $response->status());
    }

    return redirect()->back()
        ->withErrors(['error' => 'Virtual account creation failed'])
        ->withInput();
}



    public function allvirtualcard(Request $request)
    {
    
        return view('business.allvirtualcard');
    }

}
