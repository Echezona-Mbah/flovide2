<?php

namespace App\Http\Controllers\Business;

use App\Http\Controllers\Controller;
use App\Models\Beneficia;
use App\Models\TransactionHistory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class SendMoneyController extends Controller
{
    public function index()
    {
        $beneficiaries = Beneficia::where('user_id', auth()->id())->get();
        $balanceList = $this->fetchBalances(); // already the final array
        // Add 'symbol' and 'country' to each balance
        foreach ($balanceList as &$balance) {
            $extras = $this->getCountryCodeFromCurrency($balance['currency']);
            $balance['symbol'] = $extras['symbol'];
            $balance['country'] = $extras['country'];
        }
        
    
        return view('business.send', compact('beneficiaries', 'balanceList'));
    }
    

    public function fetchBalances()
    {
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . env('OHENTPAY_API_KEY'),
            'Accept' => 'application/json',
        ])->get(env('OHENTPAY_BASE_URL') . '/balances');
    
        if ($response->successful()) {
            return $response->json();
        }
    
        return [
            'error' => true,
            'message' => $response->body(),
            'status' => $response->status(),
        ];
    }

  
    public function getBalances(Request $request)
    {
        $data = $this->fetchBalances();
    
        // If error is returned from fetchBalances()
        if (isset($data['error']) && $data['error']) {
            if ($request->expectsJson()) {
                return response()->json([
                    'message' => 'Failed to fetch balances',
                    'status' => $data['status'] ?? 500,
                    'error' => true,
                    'details' => $data['message'] ?? 'Unknown error'
                ], $data['status'] ?? 500);
            }
    
            return view('balances', ['balances' => [], 'error' => $data['message'] ?? 'Failed to fetch balances']);
        }
    
        // Success response
        if ($request->expectsJson()) {
            return response()->json([
                'message' => 'Balances fetched successfully',
                'status' => 200,
                'data' => $data // Here, $data is already the array of balances
            ]);
        }
    
        return view('balances', ['balances' => $data]); // Send directly to Blade
    }
    private function getCountryCodeFromCurrency($currency)
    {
        $map = [
            'NGN' => ['symbol' => '₦', 'country' => 'ng'],
            'USD' => ['symbol' => '$', 'country' => 'us'],
            'KES' => ['symbol' => 'KSh', 'country' => 'ke'],
            'GHS' => ['symbol' => '₵', 'country' => 'gh'],
            'ZAR' => ['symbol' => 'R', 'country' => 'za'],
            'GBP' => ['symbol' => '£', 'country' => 'gb'],
            'EUR' => ['symbol' => '€', 'country' => 'eu'],
            'CAD' => ['symbol' => 'C$', 'country' => 'ca'],
            'CZK' => ['symbol' => 'Kč', 'country' => 'cz'],
            'DKK' => ['symbol' => 'kr', 'country' => 'dk'],
            'AUD' => ['symbol' => 'A$', 'country' => 'au'],
            'SEK' => ['symbol' => 'kr', 'country' => 'se'],
            'RON' => ['symbol' => 'lei', 'country' => 'ro'],
            'PLN' => ['symbol' => 'zł', 'country' => 'pl'],
            'CHF' => ['symbol' => 'CHF', 'country' => 'ch'],
            'HUF' => ['symbol' => 'Ft', 'country' => 'hu'],
            'NOK' => ['symbol' => 'kr', 'country' => 'no'],
        ];

        return $map[strtoupper($currency)] ?? ['symbol' => '', 'country' => 'us'];
    }



    public function getExchangeRate(Request $request)
    {
        // Validate required parameters
        $request->validate([
            'from_currency' => 'required|string',
            'to_currency' => 'required|string',
            'amount' => 'nullable|numeric',
        ]);
    
        $from = $request->input('from_currency');
        $to = $request->input('to_currency');
        $amount = $request->input('amount', 100); // default to 100
    
        $url = env('OHENTPAY_BASE_URL') . '/rates';
    
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . env('OHENTPAY_API_KEY'),
            'Accept' => 'application/json',
        ])->get($url, [
            'from_currency' => $from,
            'to_currency' => $to,
            'amount' => $amount
        ]);
    
        if ($response->successful()) {
            return response()->json($response->json());
        }
    
        return response()->json([
            'error' => 'Could not fetch exchange rate.',
            'response_body' => $response->body(),
            'status' => $response->status(),
            'url' => $url . '?from_currency=' . $from . '&to_currency=' . $to . '&amount=' . $amount
        ], $response->status());
    }


    // public function sendTransaction(Request $request)
    // {
    //     $request->validate([
    //         'amount' => 'required|numeric|min:1',
    //         'balance_id' => 'required|uuid',
    //         'recipient_id' => 'required|uuid',
    //         'reference' => 'nullable|string',
    //     ]);

    
    //     $orderId = (string) Str::uuid();
    
    //     $response = Http::withHeaders([
    //         'Authorization' => 'Bearer ' . env('OHENTPAY_API_KEY'),
    //         'Accept' => 'application/json',
    //     ])->post(env('OHENTPAY_BASE_URL') . '/transactions', [
    //         'transaction_type' => 'payment',
    //         'amount' => $request->amount,
    //         'balance_id' => $request->balance_id,
    //         'recipient_id' => $request->recipient_id,
    //         'order_id' => $orderId,
    //         'reference' => $request->reference ?? 'Payment via Laravel',
    //     ]);
    
    //     // Determine if it's API or Web
    //     $isApi = $request->expectsJson();
    //     $methodType = $isApi ? 'api' : 'web';

    //     if ($response->successful()) {
    //         $data = $response->json();
    //         logger()->info('Transaction Response Data:', $data);
    //         // dd($data);

    //         TransactionHistory::create([
    //             'amount' => $data['amount'] ?? null,
    //             'fees' => $data['fees'] ?? 0,
    //             'currency' => $data['currency'] ?? null,
    //             'to_currency' => $data['to_currency'] ?? null,
    //             'balance_id' => $data['balance_id'] ?? null,
    //             'virtual_account_id' => $data['virtual_account_id'] ?? null,
    //             'order_id' => $data['order_id'] ?? $orderId,
    //             'payment_reference' => $data['payment_reference'] ?? null,
    //             'status' => $data['status'] ?? 'unknown',
    //             'failure_reason' => $data['failure_reason'] ?? null,
    //             'transaction_type' => $data['transaction_type'] ?? 'payment',
    //             'payment_method' => $data['payment_method'] ?? null,
    //             'recipient_id' => $data['recipient']['id'] ?? null,
    //             'recipient_country' => $data['recipient']['country'] ?? null,
    //             'recipient_default_reference' => $data['recipient']['default_reference'] ?? null,
    //             'recipient_alias' => $data['recipient']['alias'] ?? null,
    //             'recipient_type' => $data['recipient']['type'] ?? null,
    //             'recipient_created_at' => $data['recipient']['created'] ?? null,
    //             'recipient_account_name' => $data['recipient']['bank_account']['account_name'] ?? null,
    //             'recipient_sort_code' => $data['recipient']['bank_account']['sort_code'] ?? null,
    //             'recipient_account_number' => $data['recipient']['bank_account']['account_number'] ?? null,
    //             'recipient_bank_name' => $data['recipient']['bank_account']['bank_name'] ?? null,
    //             'recipient_bank_currency' => $data['recipient']['bank_account']['currency'] ?? null,
    //             'exchange_rate' => $data['exchange_rate']['rate'] ?? null,
    //             'single_rate' => $data['exchange_rate']['single_rate'] ?? null,
    //             'reference' => $data['reference'] ?? null,
    //             'recipient_created_at' => isset($data['recipient']['created']) 
    //                 ? \Carbon\Carbon::parse($data['recipient']['created'])->format('Y-m-d H:i:s')
    //                 : null,
    //             'user_id' => $request->user()?->id ?? auth()->id(),
    //             'method' => $methodType,
    //         ]);
    
    //         if ($isApi) {
    //             return response()->json([
    //                 'message' => 'Transaction sent and recorded successfully!',
    //                 'data' => $data,
    //             ]);
    //         }
    
    //         return redirect()->route('transactionHistory')->with('success', 'Transaction sent and recorded successfully!');
    //     }
    
    //     $errorMessage = 'Transaction failed: ' . ($response->json()['failure_reason'] ?? 'Unknown error');
    
    //     if ($isApi) {
    //         return response()->json(['message' => $errorMessage], 422);
    //     }
    
    //     return back()->with('error', $errorMessage);
    // }

public function sendTransaction(Request $request)
{
    $request->validate([
        'amount' => 'required|numeric|min:1',
        'balance_id' => 'required|uuid',
        'recipient_id' => 'required|uuid',
        'reference' => 'nullable|string',
    ]);

    $orderId = (string) Str::uuid();
    $reference = $request->reference ?? 'ref-' . Str::uuid(); // Ensure unique reference

    try {
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . env('OHENTPAY_API_KEY'),
            'Accept' => 'application/json',
        ])->post(env('OHENTPAY_BASE_URL') . '/transactions', [
            'transaction_type' => 'payment',
            'amount' => $request->amount,
            'balance_id' => $request->balance_id,
            'recipient_id' => $request->recipient_id,
            'order_id' => $orderId,
            'reference' => $reference,
        ]);
    } catch (\Exception $e) {
        return $request->expectsJson()
            ? response()->json(['message' => 'API connection error', 'error' => $e->getMessage()], 500)
            : back()->with('error', 'Failed to connect to API: ' . $e->getMessage());
    }

    $isApi = $request->expectsJson();
    $methodType = $isApi ? 'api' : 'web';

    if ($response->successful()) {
        $data = $response->json();
        logger()->info('Transaction Response Data:', $data);

        $recipient = $data['recipient'] ?? [];
        $bank = $recipient['bank_account'] ?? [];
        $exchange = $data['exchange_rate'] ?? [];

        try {
            TransactionHistory::create([
                'amount' => $data['amount'] ?? null,
                'fees' => $data['fees'] ?? 0,
                'currency' => $data['currency'] ?? null,
                'to_currency' => $data['to_currency'] ?? null,
                'balance_id' => $data['balance_id'] ?? null,
                'virtual_account_id' => $data['virtual_account_id'] ?? null,
                'order_id' => $data['order_id'] ?? $orderId,
                'payment_reference' => $data['payment_reference'] ?? null,
                'status' => $data['status'] ?? 'unknown',
                'failure_reason' => $data['failure_reason'] ?? null,
                'transaction_type' => $data['transaction_type'] ?? 'payment',
                'payment_method' => $data['payment_method'] ?? null,

                // Recipient Details
                'recipient_id' => $recipient['id'] ?? null,
                'recipient_country' => $recipient['country'] ?? null,
                'recipient_default_reference' => $recipient['default_reference'] ?? null,
                'recipient_alias' => $recipient['alias'] ?? null,
                'recipient_type' => $recipient['type'] ?? null,
                'recipient_created_at' => isset($recipient['created']) 
                    ? \Carbon\Carbon::parse($recipient['created'])->format('Y-m-d H:i:s') 
                    : null,

                // Bank Info
                'recipient_account_name' => $bank['account_name'] ?? null,
                'recipient_sort_code' => $bank['sort_code'] ?? null,
                'recipient_account_number' => $bank['account_number'] ?? null,
                'recipient_bank_name' => $bank['bank_name'] ?? null,
                'recipient_bank_currency' => $bank['currency'] ?? null,

                // Exchange Rate
                'exchange_rate' => $exchange['rate'] ?? null,
                'single_rate' => $exchange['single_rate'] ?? null,

                'reference' => $data['reference'] ?? $reference,
                'user_id' => $request->user()?->id ?? auth()->id(),
                'method' => $methodType,
            ]);
        } catch (\Exception $e) {
            logger()->error('Transaction saved failed: ' . $e->getMessage());

            if ($isApi) {
                return response()->json([
                    'message' => 'Transaction succeeded, but history save failed.',
                    'error' => $e->getMessage(),
                ], 500);
            }

            return back()->with('error', 'Transaction succeeded, but not saved: ' . $e->getMessage());
        }

        // Success response
        return $isApi
            ? response()->json(['message' => 'Transaction sent and recorded successfully!', 'data' => $data])
            : redirect()->route('transactionHistory')->with('success', 'Transaction sent and recorded successfully!');
    }

    // Failed API response
    $errorMessage = 'Transaction failed: ';
    try {
        $errorData = $response->json();
        $errorMessage .= $errorData['failure_reason'] ?? 'Unknown error';
    } catch (\Exception $e) {
        $errorMessage .= 'Unable to parse error response.';
    }

    return $isApi
        ? response()->json(['message' => $errorMessage], 422)
        : back()->with('error', $errorMessage);
}


    
    
    
    

}
