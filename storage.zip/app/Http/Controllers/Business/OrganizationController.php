<?php

namespace App\Http\Controllers\Business;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class OrganizationController extends Controller
{
        public function index(Request $request)
    {
    
        return view('business.organization');
    }

         public function indexsetting(Request $request)
    {
    
        return view('business.organization_setting');
    }

        public function indexplan(Request $request)
    {
    
        return view('business.organization_plan');
    }
}
