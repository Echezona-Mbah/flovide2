<?php

namespace App\Http\Controllers\Business;

use App\Http\Controllers\Controller;
use App\Models\Countries;
use App\Models\TransactionHistory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class DashboardController extends Controller
{
    public function create() {
        $countries = Countries::all();
        $balances = $this->fetchBalances();
        $total = 0;

    
        foreach ($balances as &$balance) {
            $map = $this->getCountryCodeFromCurrency($balance['currency'] ?? 'USD');
            $balance['country'] = $map['country'] ?? 'us';
            $balance['symbol'] = $map['symbol'] ?? '';
            $total += $balance['balance'];
            $default_currency=$balance['default_currency'];

        }
        $transactions = TransactionHistory::where('user_id', auth()->id())
        ->latest('created_at')->take(5)->get();
    
        return view('dashboard', compact('countries', 'balances','total','default_currency','transactions'));
    }

    public function fetchBalances()
    {
        $response = Http::withHeaders([
            'Authorization' => 'Bearer ' . env('OHENTPAY_API_KEY'),
            'Accept' => 'application/json',
        ])->get(env('OHENTPAY_BASE_URL') . '/balances');
    
        if ($response->successful()) {
            return $response->json();
        }
    
        return [
            'error' => true,
            'message' => $response->body(),
            'status' => $response->status(),
        ];
    }


    public function getBalances()
    {
        $data = $this->fetchBalances();
    
        if (isset($data['error']) && $data['error']) {
            return view('balances', ['balances' => []]);
        }
    
        return view('balances', ['balances' => $data['balances'] ?? []]);
    }
    
    private function getCountryCodeFromCurrency($currency)
    {
        $map = [
            'NGN' => ['symbol' => '₦', 'country' => 'ng'],
            'USD' => ['symbol' => '$', 'country' => 'us'],
            'KES' => ['symbol' => 'KSh', 'country' => 'ke'],
            'GHS' => ['symbol' => '₵', 'country' => 'gh'],
            'ZAR' => ['symbol' => 'R', 'country' => 'za'],
            'GBP' => ['symbol' => '£', 'country' => 'gb'],
            'EUR' => ['symbol' => '€', 'country' => 'eu'],
            'CAD' => ['symbol' => 'C$', 'country' => 'ca'],
            'CZK' => ['symbol' => 'Kč', 'country' => 'cz'],
            'DKK' => ['symbol' => 'kr', 'country' => 'dk'],
            'AUD' => ['symbol' => 'A$', 'country' => 'au'],
            'SEK' => ['symbol' => 'kr', 'country' => 'se'],
            'RON' => ['symbol' => 'lei', 'country' => 'ro'],
            'PLN' => ['symbol' => 'zł', 'country' => 'pl'],
            'CHF' => ['symbol' => 'CHF', 'country' => 'ch'],
            'HUF' => ['symbol' => 'Ft', 'country' => 'hu'],
            'NOK' => ['symbol' => 'kr', 'country' => 'no'],
        ];
    
        return $map[strtoupper($currency)] ?? ['symbol' => '', 'country' => 'us'];
    }
    
}
