<?php

namespace App\Http\Controllers\Business;

use App\Http\Controllers\Controller;
use App\Models\AirtimeNetwork;
use App\Models\BillPayment;
use App\Models\ElectricityCompany;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;


class BillPaymentController extends Controller
{

    public function index(Request $request)
    {
        $userId = $request->user()?->id ?? auth()->id();
            $payments = BillPayment::where('user_id', $userId)
            ->latest()
            ->get();
        $serviceID = 'dstv'; 
        $variationResponse = Http::withBasicAuth(env('VTPASS_USERNAME'), env('VTPASS_PASSWORD'))
            ->get(env('VTPASS_API_URL') . '/service-variations?serviceID=' . $serviceID)
            ->json();
    
        $variations = $variationResponse['content']['variations'] ?? [];
        $electricitydata = ElectricityCompany::all();
        $airTimedata = AirtimeNetwork::all();

        //  dd($airTimedata);

        if ($request->expectsJson()) {
            return response()->json([
                'payments' => $payments,
                'variations' => $variations,
            ], 200);
        }
        return view('business.add_billpayment', compact('payments', 'variations', 'electricitydata', 'airTimedata'));
    }
    

    public function indexElectricity(Request $request)
    {
        $payments = BillPayment::where('user_id', $request->user()?->id ?? auth()->id())
            ->latest()
            ->get();

        if ($request->expectsJson()) {
            return response()->json(['data' => $payments], 200);
        }

        return view('billpayments.index', compact('payments'));
    }


    public function getVariations(Request $request)
    {
        // $request->validate([
        //     'service_id' => 'required|string',
        // ]);
    
        $url = env('VTPASS_API_URL') . '/service-variations?serviceID=' .'dstv';
    
        $response = Http::withBasicAuth(env('VTPASS_USERNAME'), env('VTPASS_PASSWORD'))
            ->get($url)
            ->json();
    
        if ($request->expectsJson()) {
            return response()->json($response);
        }
    
        return view('billpayments.variations', ['response' => $response]);
    }


    


    // Verify smartcard or biller code via VTpass API
    public function verify(Request $request)
    {
        $request->validate([
            'billers_code' => 'required|string|min:6',
        ]);
    
        $response = Http::withBasicAuth(env('VTPASS_USERNAME'), env('VTPASS_PASSWORD'))
            ->post(env('VTPASS_API_URL') . '/merchant-verify', [
                'billersCode' => $request->billers_code,
                'serviceID' => 'dstv', // Hardcoded for DSTV
                'type' => 'smartcard',
            ]);
    
        if (!$response->successful()) {
            return response()->json([
                'message' => 'Failed to verify smartcard',
                'error' => $response->json()
            ], 400);
        }
    
        return response()->json($response->json());
    }
    
    // Store payment and call VTpass pay API
    public function store(Request $request)
    {
        $rules = [
            'service_id' => 'required|string',
            'billers_code' => 'required|string',
            'variation_code' => 'required|string',
            'amount' => 'required|numeric|min:0',
            'phone' => 'required|string',
            'currency' => 'required|string',

        ];

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            if ($request->expectsJson()) {
                return response()->json(['message' => 'Validation failed', 'errors' => $validator->errors()], 422);
            }
            return redirect()->back()->withErrors($validator)->withInput();
        }
        $request_id = uniqid('vtpass_');

        $payload = [
            'request_id' => $request_id,
            'serviceID' => $request->service_id,
            'billersCode' => $request->billers_code,
            'variation_code' => $request->variation_code,
            'amount' => $request->amount,
            'phone' => $request->phone,
            'currency' => $request->currency,

        ];

        $response = Http::withBasicAuth(env('VTPASS_USERNAME'), env('VTPASS_PASSWORD'))
            ->post(env('VTPASS_API_URL') . '/pay', $payload)
            ->json();
            //dd($response);

        $status = ($response['code'] ?? '') === '000' ? 'success' : 'failed';

        $transaction = $response['content']['transactions'] ?? [];

        $payment = BillPayment::create([
            'user_id' => $request->user()?->id ?? auth()->id(),
            'request_id' => $request_id,
            'service_id' => $request->service_id,
            'variation_code' => $request->variation_code,
            'billers_code' => $request->billers_code,
            'amount' => $transaction['amount'] ?? $request->amount,
            'phone' => $transaction['phone'] ?? $request->phone,
            'currency' => $request->currency,
            'response' => $response,
            'status' => $status,
            // 'platform' => $transaction['platform'] ?? null,
            // 'product_name' => $transaction['product_name'] ?? null,
            // 'transaction_ref' => $transaction['transactionId'] ?? null,
        ]);
        

        if ($request->expectsJson()) {
            return response()->json([
                'message' => 'Payment processed',
                'status' => $status,
                'data' => $payment
            ], 201);
        }

        return redirect()->route('billpayments.store')->with('success', 'Payment processed: ' . $status);
    }

    // Delete a payment record
    public function destroy(Request $request, BillPayment $billPayment)
    {
        if ($billPayment->user_id !== ($request->user()?->id ?? auth()->id())) {
            if ($request->expectsJson()) {
                return response()->json(['message' => 'Unauthorized'], 403);
            }
            abort(403, 'Unauthorized');
        }

        $billPayment->delete();

        if ($request->expectsJson()) {
            return response()->json(['message' => 'Payment deleted successfully'], 200);
        }

        return redirect()->route('billpayments.index')->with('success', 'Payment deleted successfully.');
    }

    // public function verifyElectricity(Request $request)
    // {
    //     $rules = [
    //         'billers_code' => 'required|string',
    //         'service_id' => 'required|string',
    //         'type' => 'required|string',
    //     ];
    
    //     $validator = Validator::make($request->all(), $rules);
    
    //     if ($validator->fails()) {
    //         if ($request->expectsJson()) {
    //             return response()->json([
    //                 'message' => 'Validation failed',
    //                 'errors' => $validator->errors()
    //             ], 422);
    //         }
    //         return redirect()->back()->withErrors($validator)->withInput();
    //     }
    
    //     $response = Http::withBasicAuth(
    //         env('VTPASS_USERNAME'),
    //         env('VTPASS_PASSWORD')
    //     )->post(
    //         env('VTPASS_API_URL') . '/merchant-verify',
    //         [
    //             'billersCode' => $request->billers_code,
    //             'serviceID' => $request->service_id,
    //             'type' => $request->type,
    //         ]
    //     );
    
    //     if ($request->expectsJson()) {
    //         return response()->json([
    //             'message' => $response->successful()
    //                 ? 'Verification successful.'
    //                 : ($response->json()['message'] ?? 'Verification failed.'),
    //             'data' => $response->json()?? null,
    //             'status' => $response->status(),
    //             'method' => $request->method(),
    //             'url' => $request->fullUrl()
    //         ], $response->status());
    //     }
    
    //     return view('billpayments.verify', ['response' => $response->json()]);
    // }

    public function verifyElectricity(Request $request)
    {
        $rules = [
            'billers_code' => 'required|string',
            'service_id' => 'required|string',
            'type' => 'required|string',
        ];

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            return response()->json([
                'message' => 'Validation failed',
                'errors' => $validator->errors()
            ], 422);
        }

        $response = Http::withBasicAuth(
            env('VTPASS_USERNAME'),
            env('VTPASS_PASSWORD')
        )->post(
            env('VTPASS_API_URL') . '/merchant-verify',
            [
                'billersCode' => $request->billers_code,
                'serviceID' => $request->service_id,
                'type' => $request->type,
            ]
        );

        return response()->json([
            'message' => $response->successful()
                ? 'Verification successful.'
                : ($response->json()['message'] ?? 'Verification failed.'),
            'data' => $response->json(),
            'status' => $response->status(),
            'method' => $request->method(),
            'url' => $request->fullUrl()
        ], $response->status());
    }


    // Store payment and call VTpass pay API
    public function storeELectricity(Request $request)
    {
            $rules = [
                'service_id' => 'required|string',
                'billers_code' => 'required|string',
                'variation_code' => 'required|string',
                'amount' => 'required|numeric|min:0',
                'phone' => 'required|string',
                'currency' => 'required|string',
    
            ];
    
            $validator = Validator::make($request->all(), $rules);
            if ($validator->fails()) {
                if ($request->expectsJson()) {
                    return response()->json(['message' => 'Validation failed', 'errors' => $validator->errors()], 422);
                }
                return redirect()->back()->withErrors($validator)->withInput();
            }
            $request_id = uniqid('vtpass_');
    
            $payload = [
                'request_id' => $request_id,
                'serviceID' => $request->service_id,
                'billersCode' => $request->billers_code,
                'variation_code' => $request->variation_code,
                'amount' => $request->amount,
                'phone' => $request->phone,
                'currency' => $request->currency,
    
            ];
    
            $response = Http::withBasicAuth(env('VTPASS_USERNAME'), env('VTPASS_PASSWORD'))
                ->post(env('VTPASS_API_URL') . '/pay', $payload)
                ->json();
              //  dd($response);
    
            $status = ($response['code'] ?? '') === '000' ? 'success' : 'failed';
    
            $transaction = $response['content']['transactions'] ?? [];
    
            $payment = BillPayment::create([
                'user_id' => $request->user()?->id ?? auth()->id(),
                'request_id' => $request_id,
                'service_id' => $request->service_id,
                'variation_code' => $request->variation_code,
                'billers_code' => $request->billers_code,
                'amount' => $transaction['amount'] ?? $request->amount,
                'phone' => $transaction['phone'] ?? $request->phone,
                'currency' => $request->currency,
                'response' => $response,
                'status' => $status,
            ]);
            
    
            if ($request->expectsJson()) {
                return response()->json([
                    'message' => 'Payment processed',
                    'status' => $status,
                    'data' => $payment
                ], 200);
            }
    
            return redirect()->route('billpayments.store')->with('success', 'Payment processed: ' . $status);
    }

    // public function verifyDate(Request $request)
    // {
    //     $rules = [
    //         // 'billers_code' => 'required|string',
    //         'service_id' => 'required|string',
    //         // 'type' => 'required|string',
    //     ];
    
    //     $validator = Validator::make($request->all(), $rules);
    
    //     if ($validator->fails()) {
    //         if ($request->expectsJson()) {
    //             return response()->json([
    //                 'message' => 'Validation failed',
    //                 'errors' => $validator->errors()
    //             ], 422);
    //         }
    //         return redirect()->back()->withErrors($validator)->withInput();
    //     }
    
    //     $response = Http::withBasicAuth(
    //         env('VTPASS_USERNAME'),
    //         env('VTPASS_PASSWORD')
    //     )->post(
    //         env('VTPASS_API_URL') . '/service-variations',
    //         [
    //             // 'billersCode' => $request->billers_code,
    //             'serviceID' => $request->service_id,
    //             // 'type' => $request->type,
    //         ]
    //     );
    
    //     if ($request->expectsJson()) {
    //         return response()->json([
    //             'message' => $response->successful()
    //                 ? 'Verification successful.'
    //                 : ($response->json()['message'] ?? 'Verification failed.'),
    //             'data' => $response->json()?? null,
    //             'status' => $response->status(),
    //             'method' => $request->method(),
    //             'url' => $request->fullUrl()
    //         ], $response->status());
    //     }
    
    //     return view('billpayments.verify', ['response' => $response->json()]);
    // }

    public function getDateVariations(Request $request)
    {
        $request->validate([
            'service_id' => 'required|string',
        ]);
    
        $url = env('VTPASS_API_URL') . '/service-variations?serviceID=' . $request->service_id;
    
        try {
            $response = Http::withBasicAuth(
                env('VTPASS_USERNAME'),
                env('VTPASS_PASSWORD')
            )->get($url);
    
            $responseBody = $response->json();
    
            if (!$response->successful()) {
                return response()->json([
                    'message' => $responseBody['response_description'] ?? 'Failed to fetch variations',
                    'data' => [],
                    'status' => $response->status(),
                ], $response->status());
            }
    
            return response()->json([
                'message' => 'Service variations fetched successfully',
                'data' => $responseBody,
                'status' => 200,
            ]);
    
        } catch (\Exception $e) {
            Log::error('Variation Fetch Error:', ['error' => $e->getMessage()]);
            return response()->json([
                'message' => 'Error connecting to VTPass API',
                'data' => [],
                'status' => 500,
            ], 500);
        }
    }
    public function storeData(Request $request)
    {
            $rules = [
                'service_id' => 'required|string',
                'billers_code' => 'required|string',
                'variation_code' => 'required|string',
                'amount' => 'required|numeric|min:0',
            ];
    
            $validator = Validator::make($request->all(), $rules);
            if ($validator->fails()) {
                if ($request->expectsJson()) {
                    return response()->json(['message' => 'Validation failed', 'errors' => $validator->errors()], 422);
                }
                return redirect()->back()->withErrors($validator)->withInput();
            }
            // dd($request->all());die();
            $request_id = uniqid('vtpass_');
    
            $payload = [
                'request_id' => $request_id,
                'serviceID' => $request->service_id,
                'billersCode' => $request->billers_code,
                'variation_code' => $request->variation_code,
                'amount' => $request->amount,
                'phone' => $request->billers_code,
    
            ];
                 //   dd($payload);

            $response = Http::withBasicAuth(env('VTPASS_USERNAME'), env('VTPASS_PASSWORD'))
                ->post(env('VTPASS_API_URL') . '/pay', $payload)
                ->json();
    
            $status = ($response['code'] ?? '') === '000' ? 'success' : 'failed';
    
            $transaction = $response['content']['transactions'] ?? [];
    
            $payment = BillPayment::create([
                'user_id' => $request->user()?->id ?? auth()->id(),
                'request_id' => $request_id,
                'service_id' => $request->service_id,
                'variation_code' => $request->variation_code,
                'billers_code' => $request->billers_code,
                'amount' => $transaction['amount'] ?? $request->amount,
                'phone' => $transaction['phone'] ?? $request->phone,
                'response' => $response,
                'status' => $status,
            ]);
            
    
            if ($request->expectsJson()) {
                return response()->json([
                    'message' => 'Payment processed',
                    'status' => $status,
                    'data' => $payment
                ], 200);
            }
    
            return redirect()->route('billpayments.store')->with('success', 'Payment processed: ' . $status);
    }



    

    



}
