<?php

namespace App\Http\Controllers\Business;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ChargebackController extends Controller
{
        public function index(Request $request)
    {
    
        return view('business.chargeback');
    }
}
