<?php

namespace App\Http\Controllers\Business;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ComplianceController extends Controller
{
        public function index(Request $request)
    {
    
        return view('business.compliance');
    }
}
